$ docker-compose up
or set credentials in .env 

$ vendor/bin/phinx migrate
for database migration / table creation

$ php -S 0.0.0.0:8081